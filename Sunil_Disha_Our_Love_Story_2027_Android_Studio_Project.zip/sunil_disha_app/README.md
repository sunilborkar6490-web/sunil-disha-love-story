# Sunil & Disha — Our Love Story 2027

An offline-first Android Studio project using a local WebView app.

## Included
- 2027 daily love-note calendar with 365 date-specific entries and a daily quote.
- Original 12 monthly calendar page images rendered from the PDF supplied in the conversation.
- Calendar date selection and locally saved reminders (stored on the device using browser localStorage).
- Android WebView launcher project.

## Build an APK
This environment did not have the Android SDK / Gradle build tooling installed, so an APK could not be compiled here. To build it:
1. Install Android Studio on a computer.
2. Open this project folder (`SunilDishaLoveStory`) in Android Studio.
3. Allow Android Studio to install the required Android Gradle Plugin / SDK components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will create the APK under `app/build/outputs/apk/debug/`.

## Current reminder limitation
Reminders are saved and shown inside the app, but background alarm notifications are not implemented in this starter build. They will not alert when the app is closed. A follow-up native AlarmManager / notification implementation is needed for reliable scheduled alerts.
