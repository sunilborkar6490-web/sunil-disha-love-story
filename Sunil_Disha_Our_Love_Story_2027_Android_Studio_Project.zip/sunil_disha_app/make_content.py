import json, datetime, os
root='/mnt/data/sunil_disha_app/app/src/main/assets'
openers=[
"My dearest Disha, if I could pause one moment in this busy world, I would choose a quiet moment beside you.",
"My love, some people make a place feel like home; you make even an ordinary day feel like somewhere my heart belongs.",
"Dearest Disha, I hope you know that the smallest thoughts of you can bring the gentlest smile to my face.",
"My darling, loving you has taught me that tenderness can live in the simplest moments and the quietest words.",
"To the woman who holds such a beautiful place in my heart, today I am sending you a little reminder of my affection.",
"My love, even when the day is full of noise, the thought of you brings a rare kind of calm to my heart.",
"Disha, if affection could be wrapped into a letter, I would fill every page with reasons to cherish you.",
"My dearest, I do not need a grand occasion to celebrate you; an ordinary day is reason enough.",
"Sweetheart, the world keeps moving so quickly, but my favourite thoughts are the ones that gently lead me back to you.",
"My love, there is something beautiful about knowing that one person can make life feel warmer simply by being in it.",
"Disha, today I want to remind you that you are appreciated not only for what you do, but for the person you are.",
"My darling, every sunrise brings another chance to be kinder, more patient, and more thoughtful with the people we love.",
"To my favourite thought, I hope this little note finds you surrounded by softness, peace, and reasons to smile.",
"My love, I often find that the most meaningful feelings are not loud; they are steady, gentle, and present.",
"Dearest Disha, if today feels ordinary, let this message make it a little less ordinary and a little more special.",
"My sweetheart, I wish I could place a little sunshine beside you and remind you how precious you are to me.",
"Disha, some days call for big celebrations, while others simply deserve a sincere message from the heart.",
"My love, I hope you never underestimate the beauty you bring into the lives and moments around you.",
"My dearest, there are countless things I could say, but today I want to begin with one simple truth: you matter to me.",
"Sweet Disha, may this note feel like a gentle hand in yours and a warm pause in the middle of your day.",
"My darling, affection is not only found in special dates; it is also found in remembering, listening, and showing up.",
"My love, I am sending you a thought that has no demand attached to it—only warmth, respect, and care.",
"Dearest Disha, I hope you give yourself the same kindness that you so naturally deserve from the world.",
"My sweetheart, even a few words can carry a sincere feeling when they are written with care.",
"To you, Disha, with all the warmth this day can hold: here is a small reminder that you are deeply cherished."
]
middles=[
"I treasure the little details: the way a conversation can stretch without feeling long, the comfort of familiar memories, and the happiness hidden inside simple plans. Those moments remind me that love is often built quietly, one thoughtful gesture at a time.",
"I want our story to be made of patience, honesty, laughter, and the courage to understand one another. Perfect days are not necessary; what matters is meeting each day with a generous heart and choosing kindness whenever we can.",
"You deserve to feel respected, heard, encouraged, and free to be completely yourself. I hope the people around you make room for your dreams, celebrate your strengths, and support you gently on the days that ask more of you.",
"If life becomes complicated, I hope we remember to slow down, speak with care, and never let pride become louder than compassion. The strongest affection is not a performance; it is shown through consistency and consideration.",
"I wish you a day filled with small victories: a peaceful morning, a reason to laugh, work that feels meaningful, and a quiet evening that lets your mind rest. You deserve happiness in the everyday details, not only on special occasions.",
"When I think about the future, I hope for more shared stories, thoughtful conversations, new places, and memories that make us smile years later. I hope we keep learning about each other rather than assuming we already know everything.",
"There is beauty in being able to celebrate another person's individuality. Keep your hopes, your voice, your friendships, and your ambitions close. The right kind of love makes space for a person to grow, not smaller to fit a picture.",
"I may not always find the perfect words, but I can keep trying to express what matters: gratitude for your presence, respect for your choices, and a sincere wish to see you happy and fulfilled.",
"Let today be a reminder that affection can be gentle. It can be a message at the right time, a patient reply, a shared joke, or the simple decision to listen without rushing to speak.",
"I hope we never stop noticing the little things that make life beautiful: changing skies, favourite songs, unexpected laughter, warm cups of tea, and the comfort of being understood without needing to explain every feeling.",
"You are allowed to have difficult days, change your mind, chase new dreams, and take the time you need. You do not have to be perfect to be worthy of tenderness, appreciation, and respect.",
"My wish is that our memories keep growing in a healthy and beautiful way—with trust instead of fear, freedom instead of pressure, and honesty instead of guesswork. That is the kind of connection worth nurturing.",
"I hope this day gives you a reason to pause and recognise how far you have come. Every effort counts, even the quiet ones nobody else notices. I am cheering for your happiness and your becoming.",
"A beautiful relationship is not measured only by grand gestures. It is reflected in everyday respect, in keeping promises, in giving each other room to breathe, and in finding joy in the ordinary.",
"Whatever this day brings, I hope you meet it knowing that your dreams matter. Keep making plans that excite you, protect your peace, and never forget that your individuality is part of what makes you wonderful.",
"I love the idea of building a collection of ordinary moments that become extraordinary with time. A walk, a meal, a silly photograph, a long conversation—these are the pages that make a life feel rich.",
"May we always choose curiosity over assumptions and conversation over silence. Understanding takes effort, but it is a beautiful effort when both hearts are willing to be honest and kind.",
"The world may measure success in milestones, but I hope you also measure it in peace, meaningful friendships, good health, and the freedom to enjoy the life you are creating.",
"I hope you feel proud of the person you are becoming. Keep your softness without surrendering your strength, and keep your strength without losing your ability to be gentle.",
"Even from a distance, a thoughtful message can say: I am wishing you well, I believe in your possibilities, and I hope something lovely finds you today.",
"Let us keep making room for joy, forgiveness, adventure, and quiet evenings. The most precious memories often arrive without an announcement, when we are simply present with one another.",
"I hope we can be each other's encouragement while still honouring our own paths. Love should add warmth to life, support growth, and make room for two complete people to shine.",
"Today, I am grateful for the chance to tell you something kind. Never let a busy schedule convince you that you are not worth celebrating. You are worthy of care on ordinary Tuesdays and every day in between.",
"I hope the next chapter brings you confidence, meaningful opportunities, and beautiful surprises. Whatever you choose to pursue, may you do it with courage and a heart that remains true to itself.",
"A thousand grand words cannot replace one sincere action. So let this note be a promise to keep affection thoughtful, communication honest, and respect present in the smallest details."
]
closers=[
"Take a deep breath, smile if you can, and remember that you deserve a day as lovely as the kindness you give. With warmth, always.",
"May your heart feel light tonight and your dreams feel possible tomorrow. Sending you all my affection.",
"If this note brings even a small smile, then it has done exactly what I hoped. You are cherished, today and always.",
"Keep shining in your own way, Disha. The world is brighter when you allow yourself to be fully you.",
"Here is to more honest conversations, gentle memories, and reasons to be grateful. With love, from Sunil.",
"I hope you end this day feeling appreciated and begin the next one with fresh hope. You deserve both.",
"No grand occasion is needed for me to wish you happiness. Today, tomorrow, and on all the quiet days too.",
"May this little message stay with you like a favourite melody—soft, familiar, and full of warmth.",
"Whatever happens today, please be gentle with yourself. You are important, and your happiness matters.",
"With a grateful heart and a thousand good wishes, I am sending you a little love across the day."
]
qstarts=["Love is", "A beautiful bond is", "The sweetest kind of affection is", "A heart feels at home when", "Romance becomes meaningful when", "The quiet magic of love is", "A lasting connection is", "The loveliest promise is", "Tenderness is", "A shared tomorrow begins with"]
qends=["choosing kindness in the smallest moments.","making room for two people to keep growing.","remembering that respect is part of every love story.","turning ordinary hours into treasured memories.","listening with patience and speaking with honesty.","celebrating each other's dreams without holding them back.","being present without needing a perfect occasion.","finding joy in the little things that time cannot replace.","offering warmth while allowing each heart to remain free.","showing up with care, even when words are few."]
entries=[]
start=datetime.date(2027,1,1)
for i in range(365):
    d=start+datetime.timedelta(days=i)
    a=openers[i%len(openers)]
    b=middles[(i*7 + i//25)%len(middles)]
    c=closers[(i*3 + i//11)%len(closers)]
    # unique date-tail makes each daily letter genuinely date-specific without repeating
    msg=f"{a} {b} {c} Today, on {d.strftime('%B %d')}, I am wishing you a beautiful day and a heart full of hope."
    quote=f"{qstarts[i%len(qstarts)]} {qends[(i*7 + i//10)%len(qends)]}"
    # Distinguish quote daily with a fresh poetic day-specific ending
    quote += f" — A little thought for {d.strftime('%B %d')}"
    entries.append({'date':d.isoformat(),'message':msg,'quote':quote})
with open(os.path.join(root,'daily-love.json'),'w') as f: json.dump(entries,f,ensure_ascii=False)
